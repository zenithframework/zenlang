import unittest
from zenith.token import Token, TokenType
from zenith.lexer import Lexer

class TestLexer(unittest.TestCase):
    def test_string_token(self):
        source = '"hello world"'
        lexer = Lexer(source)
        token = lexer.next_token()
        self.assertEqual(token.token_type, TokenType.STRING)
        self.assertEqual(token.literal, "hello world")

    def test_simple_tokens(self):
        source = "=+-(){},;"
        expected_tokens = [
            Token(TokenType.ASSIGN, '='),
            Token(TokenType.PLUS, '+'),
            Token(TokenType.MINUS, '-'),
            Token(TokenType.LPAREN, '('),
            Token(TokenType.RPAREN, ')'),
            Token(TokenType.LBRACE, '{'),
            Token(TokenType.RBRACE, '}'),
            Token(TokenType.COMMA, ','),
            Token(TokenType.SEMICOLON, ';'),
            Token(TokenType.EOF, ""),
        ]
        lexer = Lexer(source)
        for expected in expected_tokens:
            token = lexer.next_token()
            self.assertEqual(token.token_type, expected.token_type)
            self.assertEqual(token.literal, expected.literal)

    def test_let_statement(self):
        source = "let five = 5;"
        expected_tokens = [
            Token(TokenType.LET, 'let'),
            Token(TokenType.IDENTIFIER, 'five'),
            Token(TokenType.ASSIGN, '='),
            Token(TokenType.INTEGER, '5'),
            Token(TokenType.SEMICOLON, ';'),
            Token(TokenType.EOF, ""),
        ]
        lexer = Lexer(source)
        for expected in expected_tokens:
            token = lexer.next_token()
            self.assertEqual(token.token_type, expected.token_type)
            self.assertEqual(token.literal, expected.literal)

if __name__ == '__main__':
    unittest.main()
