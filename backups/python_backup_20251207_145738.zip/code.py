import struct
from typing import List, NamedTuple

# Opcodes as single bytes
OP_CONSTANT = 0x01
OP_ADD = 0x02
OP_POP = 0x03
OP_SUB = 0x04
OP_MUL = 0x05
OP_DIV = 0x06
OP_TRUE = 0x07
OP_FALSE = 0x08
OP_EQ = 0x09
OP_NOT_EQ = 0x0A
OP_GT = 0x0B # Greater Than, others can be derived from this and OpNot
OP_JUMP_NOT_TRUE = 0x0C
OP_JUMP = 0x0D
OP_NULL = 0x0E


class Definition(NamedTuple):
    name: str
    operand_widths: List[int]

definitions = {
    OP_CONSTANT: Definition("OpConstant", [2]),
    OP_ADD: Definition("OpAdd", []),
    OP_POP: Definition("OpPop", []),
    OP_SUB: Definition("OpSubtract", []),
    OP_MUL: Definition("OpMultiply", []),
    OP_DIV: Definition("OpDivide", []),
    OP_TRUE: Definition("OpTrue", []),
    OP_FALSE: Definition("OpFalse", []),
    OP_EQ: Definition("OpEqual", []),
    OP_NOT_EQ: Definition("OpNotEqual", []),
    OP_GT: Definition("OpGreaterThan", []),
    OP_JUMP_NOT_TRUE: Definition("OpJumpNotTrue", [2]),
    OP_JUMP: Definition("OpJump", [2]),
    OP_NULL: Definition("OpNull", []),
}

def make(op: int, *operands: int) -> bytearray:
    """Creates a bytecode instruction from an opcode and its operands."""
    try:
        definition = definitions[op]
    except KeyError:
        return bytearray()

    instruction = bytearray([op])
    for i, operand in enumerate(operands):
        width = definition.operand_widths[i]
        if width == 2:
            # Pack operand as a 2-byte unsigned big-endian integer
            instruction.extend(struct.pack(">H", operand))
    return instruction

def to_string(ins: bytearray) -> str:
    """Provides a string representation of bytecode for debugging."""
    out = ""
    i = 0
    while i < len(ins):
        op = ins[i]
        out += f"{i:04d} "
        if op in definitions:
            definition = definitions[op]
            operands, read = read_operands(definition, ins[i+1:])
            out += f"{definition.name} {' '.join(map(str, operands))}\n"
            i += 1 + read
        else:
            out += f"ERROR: Unknown opcode {op}\n"
            i += 1
    return out

def read_operands(definition: Definition, ins: bytearray) -> (List[int], int):
    """Reads the operands for an instruction."""
    operands = []
    offset = 0
    for width in definition.operand_widths:
        if width == 2:
            operand = struct.unpack(">H", ins[offset:offset+width])[0]
            operands.append(operand)
        offset += width
    return operands, offset
