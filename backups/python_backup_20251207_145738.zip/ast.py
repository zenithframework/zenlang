from abc import ABC, abstractmethod
from typing import List, Optional
from .token import Token

# Base classes
class Node(ABC):
    @abstractmethod
    def token_literal(self) -> str:
        pass

    def __str__(self) -> str:
        return f"AST Node"

class Statement(Node):
    pass

class Expression(Node):
    pass

# Root of the AST
class Program(Node):
    def __init__(self):
        self.statements: List[Statement] = []

    def token_literal(self) -> str:
        if self.statements:
            return self.statements[0].token_literal()
        return ""

    def __str__(self) -> str:
        return "".join(str(s) for s in self.statements)

# Expressions
class Identifier(Expression):
    def __init__(self, token: Token, value: str):
        self.token = token
        self.value = value

    def token_literal(self) -> str:
        return self.token.literal

    def __str__(self) -> str:
        return self.value

class IntegerLiteral(Expression):
    def __init__(self, token: Token, value: int):
        self.token = token
        self.value = value
    
    def token_literal(self) -> str:
        return self.token.literal

    def __str__(self) -> str:
        return str(self.value)

class BooleanLiteral(Expression):
    def __init__(self, token: Token, value: bool):
        self.token = token
        self.value = value

    def token_literal(self) -> str:
        return self.token.literal
    
    def __str__(self) -> str:
        return self.token.literal

class PrefixExpression(Expression):
    def __init__(self, token: Token, operator: str, right: Expression):
        self.token = token
        self.operator = operator
        self.right = right
    
    def token_literal(self) -> str:
        return self.token.literal

    def __str__(self) -> str:
        return f"({self.operator}{str(self.right)})"

class InfixExpression(Expression):
    def __init__(self, token: Token, left: Expression, operator: str, right: Expression):
        self.token = token
        self.left = left
        self.operator = operator
        self.right = right
    
    def token_literal(self) -> str:
        return self.token.literal

    def __str__(self) -> str:
        return f"({str(self.left)} {self.operator} {str(self.right)})"

class BlockStatement(Statement):
    def __init__(self, token: Token):
        self.token = token # The '{' token
        self.statements: List[Statement] = []

    def token_literal(self) -> str:
        return self.token.literal
    
    def __str__(self) -> str:
        return "".join(str(s) for s in self.statements)

class IfExpression(Expression):
    def __init__(self, token: Token, condition: Expression, consequence: BlockStatement, alternative: Optional[BlockStatement] = None):
        self.token = token # The 'if' token
        self.condition = condition
        self.consequence = consequence
        self.alternative = alternative
    
    def token_literal(self) -> str:
        return self.token.literal

    def __str__(self) -> str:
        out = f"if {str(self.condition)} {str(self.consequence)}"
        if self.alternative:
            out += f"else {str(self.alternative)}"
        return out

# Statements
class LetStatement(Statement):
    def __init__(self, token: Token, name: Identifier, value: Optional[Expression] = None):
        self.token = token  # The 'let' token
        self.name = name
        self.value = value

    def token_literal(self) -> str:
        return self.token.literal
    
    def __str__(self) -> str:
        val_str = str(self.value) if self.value else ""
        return f"{self.token_literal()} {str(self.name)} = {val_str};"

class ReturnStatement(Statement):
    def __init__(self, token: Token, return_value: Optional[Expression] = None):
        self.token = token # The 'return' token
        self.return_value = return_value

    def token_literal(self) -> str:
        return self.token.literal

    def __str__(self) -> str:
        val_str = str(self.return_value) if self.return_value else ""
        return f"{self.token_literal()} {val_str};"

class ExpressionStatement(Statement):
    def __init__(self, token: Token, expression: Expression):
        self.token = token
        self.expression = expression

    def token_literal(self) -> str:
        return self.token.literal

    def __str__(self) -> str:
        return str(self.expression)
