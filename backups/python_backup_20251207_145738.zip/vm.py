from . import code
from . import object
from typing import List

STACK_SIZE = 2048

class VM:
    def __init__(self, bytecode):
        self.instructions = bytecode[0]
        # Wrap integer constants in Integer objects
        self.constants = [object.Integer(c) if isinstance(c, int) else c for c in bytecode[1]]
        
        self.stack = [None] * STACK_SIZE
        self.sp = 0  # Always points to the next free slot in the stack

        self.ip = 0 # Instruction Pointer

    def run(self):
        while self.ip < len(self.instructions):
            op = self.instructions[self.ip]
            self.ip += 1

            if op == code.OP_CONSTANT:
                const_index = int.from_bytes(self.instructions[self.ip:self.ip+2], "big")
                self.ip += 2
                self._push(self.constants[const_index])
            
            elif op in [code.OP_ADD, code.OP_SUB, code.OP_MUL, code.OP_DIV]:
                self._execute_binary_operation(op)
            
            elif op in [code.OP_EQ, code.OP_NOT_EQ, code.OP_GT]:
                self._execute_comparison(op)

            elif op == code.OP_TRUE:
                self._push(object.TRUE)
            
            elif op == code.OP_FALSE:
                self._push(object.FALSE)
            
            elif op == code.OP_NULL:
                self._push(object.NULL)

            elif op == code.OP_JUMP_NOT_TRUE:
                pos = int.from_bytes(self.instructions[self.ip:self.ip+2], "big")
                self.ip += 2
                condition = self._pop()
                if not self._is_truthy(condition):
                    self.ip = pos
            
            elif op == code.OP_JUMP:
                pos = int.from_bytes(self.instructions[self.ip:self.ip+2], "big")
                self.ip = pos
            
            elif op == code.OP_POP:
                self._pop()

    def _is_truthy(self, obj: object.Object) -> bool:
        if obj == object.TRUE:
            return True
        if obj == object.FALSE:
            return False
        if obj == object.NULL:
            return False
        # Treat all other objects (e.g., Integer(0)) as truthy for now
        return True

    def _execute_binary_operation(self, op: int):
        right = self._pop()
        left = self._pop()

        if isinstance(left, object.Integer) and isinstance(right, object.Integer):
            if op == code.OP_ADD:
                self._push(object.Integer(left.value + right.value))
            elif op == code.OP_SUB:
                self._push(object.Integer(left.value - right.value))
            elif op == code.OP_MUL:
                self._push(object.Integer(left.value * right.value))
            elif op == code.OP_DIV:
                # Add check for division by zero later
                self._push(object.Integer(left.value // right.value))
        else:
            # Handle other types later
            raise Exception(f"unsupported types for binary operation: {type(left)} and {type(right)}")

    def _execute_comparison(self, op: int):
        right = self._pop()
        left = self._pop()

        if isinstance(left, object.Integer) and isinstance(right, object.Integer):
            if op == code.OP_EQ:
                self._push(object.Boolean(left.value == right.value))
            elif op == code.OP_NOT_EQ:
                self._push(object.Boolean(left.value != right.value))
            elif op == code.OP_GT:
                self._push(object.Boolean(left.value > right.value))
        elif isinstance(left, object.Boolean) and isinstance(right, object.Boolean):
            if op == code.OP_EQ:
                self._push(object.Boolean(left.value == right.value))
            elif op == code.OP_NOT_EQ:
                self._push(object.Boolean(left.value != right.value))
            elif op == code.OP_GT: # Booleans don't have a natural > comparison, so treat as false
                self._push(object.FALSE) 
        else:
            raise Exception(f"unsupported types for comparison: {type(left)} and {type(right)}")


    def _push(self, obj: object.Object):
        if self.sp >= STACK_SIZE:
            raise Exception("Stack overflow")
        self.stack[self.sp] = obj
        self.sp += 1

    def _pop(self) -> object.Object:
        if self.sp == 0:
            return None
        self.sp -= 1
        obj = self.stack[self.sp]
        return obj

    def last_popped_stack_elem(self) -> object.Object:
        if self.sp >= len(self.stack):
             return None
        return self.stack[self.sp]
