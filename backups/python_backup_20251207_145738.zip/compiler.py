from . import ast
from . import code
from .token import TokenType

class Compiler:
    def __init__(self):
        self.instructions = bytearray()
        self.constants = []

    def compile(self, node: ast.Node):
        if isinstance(node, ast.Program):
            for stmt in node.statements:
                self.compile(stmt)

        elif isinstance(node, ast.ExpressionStatement):
            self.compile(node.expression)
            self.emit(code.OP_POP)

        elif isinstance(node, ast.InfixExpression):
            # Special handling for '<' as our VM only has OpGreaterThan
            if node.operator == '<':
                # Compile right then left, then emit OpGreaterThan
                self.compile(node.right)
                self.compile(node.left)
                self.emit(code.OP_GT)
                return
            
            self.compile(node.left)
            self.compile(node.right)
            
            if node.operator == '+':
                self.emit(code.OP_ADD)
            elif node.operator == '-':
                self.emit(code.OP_SUB)
            elif node.operator == '*':
                self.emit(code.OP_MUL)
            elif node.operator == '/':
                self.emit(code.OP_DIV)
            elif node.operator == '==':
                self.emit(code.OP_EQ)
            elif node.operator == '!=':
                self.emit(code.OP_NOT_EQ)
            elif node.operator == '>':
                self.emit(code.OP_GT)
            else:
                raise Exception(f"unknown operator: {node.operator}")

        elif isinstance(node, ast.IntegerLiteral):
            constant_pos = self._add_constant(node.value)
            self.emit(code.OP_CONSTANT, constant_pos)
        
        elif isinstance(node, ast.BooleanLiteral):
            if node.value:
                self.emit(code.OP_TRUE)
            else:
                self.emit(code.OP_FALSE)
        
        elif isinstance(node, ast.IfExpression):
            self.compile(node.condition)

            # Emit a placeholder for OpJumpNotTrue. We'll patch it later.
            jump_not_true_pos = self._emit_with_placeholder(code.OP_JUMP_NOT_TRUE, 9999) # 9999 is a placeholder

            self.compile(node.consequence)

            if len(self.instructions) > 0 and self.instructions[-1] == code.OP_POP:
                # Remove the implicit POP if the consequence is a block ending with an expression
                # This ensures the expression's result stays on the stack
                del self.instructions[-1]


            if node.alternative:
                # Emit a placeholder for OpJump. This jumps over the else branch.
                jump_pos = self._emit_with_placeholder(code.OP_JUMP, 9999)

                # Patch the OpJumpNotTrue target
                self._change_operand(jump_not_true_pos, len(self.instructions))
                
                self.compile(node.alternative)

                if len(self.instructions) > 0 and self.instructions[-1] == code.OP_POP:
                    del self.instructions[-1]

                # Patch the OpJump target
                self._change_operand(jump_pos, len(self.instructions))
            else:
                # If no alternative, jump to here (after consequence)
                self._change_operand(jump_not_true_pos, len(self.instructions))
                
            # If both branches are empty, or the evaluated result isn't explicitly
            # popped, ensure a Null is pushed for consistent stack behavior.
            # This handles cases like `if (true) {}`
            if (not node.consequence.statements) and (not node.alternative or not node.alternative.statements):
                self.emit(code.OP_NULL)


        elif isinstance(node, ast.BlockStatement):
            for stmt in node.statements:
                self.compile(stmt)

    def _add_constant(self, obj) -> int:
        self.constants.append(obj)
        return len(self.constants) - 1

    def emit(self, op: int, *operands: int):
        ins = code.make(op, *operands)
        self.instructions.extend(ins)

    def _emit_with_placeholder(self, op: int, operand_value: int) -> int:
        pos = len(self.instructions)
        ins = code.make(op, operand_value) # 9999 is a placeholder
        self.instructions.extend(ins)
        return pos

    def _change_operand(self, op_pos: int, operand_value: int):
        definition = code.definitions[self.instructions[op_pos]]
        if len(definition.operand_widths) == 0:
            raise Exception("cannot change operand of 0-byte instruction")
        
        # Assume 2-byte operand for now
        instruction = code.make(self.instructions[op_pos], operand_value)
        self.instructions[op_pos:op_pos + len(instruction)] = instruction

    def bytecode(self):
        return (self.instructions, self.constants)
