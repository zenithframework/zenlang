import unittest
from zenith import ast, code, parser, lexer, compiler, vm, object

class VMTestCase(unittest.TestCase):
    def _run_vm_test(self, source: str, expected):
        program = self._parse(source)
        c = self._compile(program)
        machine = vm.VM(c.bytecode())
        machine.run()
        
        stack_elem = machine.last_popped_stack_elem()
        self.assertIsNotNone(stack_elem) # Changed: This can be None if result is Null
        self._test_object(stack_elem, expected)

    def _parse(self, source: str) -> ast.Program:
        l = lexer.Lexer(source)
        p = parser.Parser(l)
        program = p.parse_program()
        self.assertEqual(len(p.errors), 0, f"parser has {len(p.errors)} errors: {p.errors}")
        return program

    def _compile(self, program: ast.Program) -> 'compiler.Compiler':
        c = compiler.Compiler()
        c.compile(program)
        return c

    def _test_object(self, actual, expected):
        if type(expected) is int:
            self.assertIsInstance(actual, object.Integer)
            self.assertEqual(actual.value, expected)
        elif type(expected) is bool:
            self.assertIsInstance(actual, object.Boolean)
            self.assertEqual(actual.value, expected)
        elif expected is None: # For NULL
            self.assertEqual(actual, object.NULL)
        else:
            self.fail(f"unhandled expected type: {type(expected)}")


class TestVM(VMTestCase):
    def test_integer_arithmetic(self):
        tests = [
            ("1", 1),
            ("2", 2),
            ("1 + 2", 3),
            ("1 - 2", -1),
            ("2 * 3", 6),
            ("4 / 2", 2), # Note: vm does integer division
            ("50 / 2 * 2 + 10 - 5", 55),
        ]
        for source, expected in tests:
            self._run_vm_test(source, expected)

    def test_boolean_expressions(self):
        tests = [
            ("true", True),
            ("false", False),
        ]
        for source, expected in tests:
            self._run_vm_test(source, expected)

    def test_comparison_operators(self):
        tests = [
            ("1 == 1", True),
            ("1 != 1", False),
            ("1 > 1", False),
            ("1 < 1", False), # Compiler converts to `1 > 1` (false)
            ("1 == 2", False),
            ("1 != 2", True),
            ("1 > 2", False),
            ("1 < 2", True), # Compiler converts to `2 > 1` (true)
            ("true == true", True),
            ("true != false", True),
            ("false == false", True),
        ]
        for source, expected in tests:
            self._run_vm_test(source, expected)

    def test_if_else_expressions(self):
        tests = [
            ("if (true) { 10 }", 10),
            ("if (false) { 10 }", None),
            ("if (1 > 2) { 10 }", None),
            ("if (1 < 2) { 10 }", 10),
            ("if (1 < 2) { 10 } else { 20 }", 10),
            ("if (1 > 2) { 10 } else { 20 }", 20),
        ]
        for source, expected in tests:
            self._run_vm_test(source, expected)


if __name__ == '__main__':
    unittest.main()
