import unittest
from zenith import ast, code, parser, lexer, compiler

class TestCompiler(unittest.TestCase):
    def test_integer_arithmetic(self):
        tests = [
            ("1 + 2", [1, 2], [code.make(code.OP_CONSTANT, 0), code.make(code.OP_CONSTANT, 1), code.make(code.OP_ADD), code.make(code.OP_POP)]),
            ("1 - 2", [1, 2], [code.make(code.OP_CONSTANT, 0), code.make(code.OP_CONSTANT, 1), code.make(code.OP_SUB), code.make(code.OP_POP)]),
            ("2 * 3", [2, 3], [code.make(code.OP_CONSTANT, 0), code.make(code.OP_CONSTANT, 1), code.make(code.OP_MUL), code.make(code.OP_POP)]),
            ("4 / 2", [4, 2], [code.make(code.OP_CONSTANT, 0), code.make(code.OP_CONSTANT, 1), code.make(code.OP_DIV), code.make(code.OP_POP)]),
        ]

        for source, constants, instructions in tests:
            program = self._parse(source)
            c = self._compile(program)
            bytecode = c.bytecode()
            
            # Flatten the list of bytearray instructions into a single list of bytes
            expected_instructions_flat = [byte for ins in instructions for byte in ins]
            
            self.assertEqual(list(bytecode[0]), expected_instructions_flat, f"instructions wrong for {source}")
            self.assertEqual(bytecode[1], constants, f"constants wrong for {source}")
    
    def _parse(self, source: str) -> ast.Program:
        l = lexer.Lexer(source)
        p = parser.Parser(l)
        program = p.parse_program()
        # Check for parser errors
        self.assertEqual(len(p.errors), 0, f"parser has {len(p.errors)} errors: {p.errors}")
        return program

    def _compile(self, program: ast.Program) -> 'Compiler':
        c = compiler.Compiler()
        c.compile(program)
        return c

if __name__ == '__main__':
    unittest.main()
