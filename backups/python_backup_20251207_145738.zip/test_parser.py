import unittest
from zenith.lexer import Lexer
from zenith.parser import Parser
from zenith.ast import (
    LetStatement, Identifier, ReturnStatement, ExpressionStatement, IntegerLiteral, PrefixExpression, InfixExpression, IfExpression, BlockStatement
)

class TestParser(unittest.TestCase):

    def test_let_statements(self):
        source = """
        let x = 5;
        let y = 10;
        let foobar = 838383;
        """
        lexer = Lexer(source)
        parser = Parser(lexer)
        program = parser.parse_program()
        self.assertIsNotNone(program)
        self.assertEqual(len(program.statements), 3)
        
        tests = ["x", "y", "foobar"]
        for i, tt in enumerate(tests):
            stmt = program.statements[i]
            self.assertIsInstance(stmt, LetStatement)
            self.assertEqual(stmt.name.value, tt)
            self.assertEqual(stmt.name.token_literal(), tt)

    def test_return_statements(self):
        source = """
        return 5;
        return 10;
        return 993322;
        """
        lexer = Lexer(source)
        parser = Parser(lexer)
        program = parser.parse_program()
        self.assertIsNotNone(program)
        self.assertEqual(len(program.statements), 3)

        for stmt in program.statements:
            self.assertIsInstance(stmt, ReturnStatement)
            self.assertEqual(stmt.token_literal(), "return")

    def test_identifier_expression(self):
        source = "foobar;"
        lexer = Lexer(source)
        parser = Parser(lexer)
        program = parser.parse_program()
        self.assertEqual(len(program.statements), 1)
        stmt = program.statements[0]
        self.assertIsInstance(stmt, ExpressionStatement)
        
        ident = stmt.expression
        self.assertIsInstance(ident, Identifier)
        self.assertEqual(ident.value, "foobar")
        self.assertEqual(ident.token_literal(), "foobar")

    def test_integer_literal_expression(self):
        source = "5;"
        lexer = Lexer(source)
        parser = Parser(lexer)
        program = parser.parse_program()
        self.assertEqual(len(program.statements), 1)
        stmt = program.statements[0]
        self.assertIsInstance(stmt, ExpressionStatement)
        
        literal = stmt.expression
        self.assertIsInstance(literal, IntegerLiteral)
        self.assertEqual(literal.value, 5)
        self.assertEqual(literal.token_literal(), "5")

    def test_parsing_prefix_expressions(self):
        prefix_tests = [
            ("!5;", "!", 5),
            ("-15;", "-", 15),
        ]
        for source, operator, value in prefix_tests:
            lexer = Lexer(source)
            parser = Parser(lexer)
            program = parser.parse_program()
            self.assertEqual(len(program.statements), 1)
            stmt = program.statements[0]
            self.assertIsInstance(stmt, ExpressionStatement)
            
            exp = stmt.expression
            self.assertIsInstance(exp, PrefixExpression)
            self.assertEqual(exp.operator, operator)
            self.assertEqual(exp.right.value, value)

    def test_parsing_infix_expressions(self):
        infix_tests = [
            ("5 + 5;", 5, "+", 5),
            ("5 - 5;", 5, "-", 5),
            ("5 * 5;", 5, "*", 5),
            ("5 / 5;", 5, "/", 5),
            ("5 > 5;", 5, ">", 5),
            ("5 < 5;", 5, "<", 5),
            ("5 == 5;", 5, "==", 5),
            ("5 != 5;", 5, "!=", 5),
        ]
        for source, left_val, operator, right_val in infix_tests:
            lexer = Lexer(source)
            parser = Parser(lexer)
            program = parser.parse_program()
            self.assertEqual(len(program.statements), 1)
            stmt = program.statements[0]
            self.assertIsInstance(stmt, ExpressionStatement)
            
            exp = stmt.expression
            self.assertIsInstance(exp, InfixExpression)
            self.assertEqual(exp.left.value, left_val)
            self.assertEqual(exp.operator, operator)
            self.assertEqual(exp.right.value, right_val)

    def test_operator_precedence_parsing(self):
        tests = [
            ("-a * b", "((-a) * b)"),
            ("!-a", "(!(-a))"),
            ("a + b + c", "((a + b) + c)"),
            ("a + b - c", "((a + b) - c)"),
            ("a * b * c", "((a * b) * c)"),
            ("a * b / c", "((a * b) / c)"),
            ("a + b / c", "(a + (b / c))"),
            ("a + b * c + d / e - f", "(((a + (b * c)) + (d / e)) - f)"),
            ("5 > 4 == 3 < 4", "((5 > 4) == (3 < 4))"),
            ("5 < 4 != 3 > 4", "((5 < 4) != (3 > 4))"),
            ("1 + (2 + 3) + 4", "((1 + (2 + 3)) + 4)"),
            ("(5 + 5) * 2", "((5 + 5) * 2)"),
            ("-(1 + 2)", "(-(1 + 2))"),
        ]
        for source, expected_str in tests:
            lexer = Lexer(source)
            parser = Parser(lexer)
            program = parser.parse_program()
            actual_str = str(program)
            self.assertEqual(actual_str, expected_str)
            self.assertEqual(len(parser.errors), 0, parser.errors)
    
    def test_if_expression(self):
        source = "if (x < y) { x }"
        lexer = Lexer(source)
        parser = Parser(lexer)
        program = parser.parse_program()
        self.assertEqual(len(parser.errors), 0, parser.errors)
        self.assertEqual(len(program.statements), 1)

        stmt = program.statements[0]
        self.assertIsInstance(stmt, ExpressionStatement)
        
        exp = stmt.expression
        self.assertIsInstance(exp, IfExpression)
        self.assertEqual(str(exp.condition), "(x < y)")
        self.assertEqual(str(exp.consequence), "x")
        self.assertIsNone(exp.alternative)

    def test_if_else_expression(self):
        source = "if (x < y) { x } else { y }"
        lexer = Lexer(source)
        parser = Parser(lexer)
        program = parser.parse_program()
        self.assertEqual(len(parser.errors), 0, parser.errors)
        self.assertEqual(len(program.statements), 1)

        stmt = program.statements[0]
        self.assertIsInstance(stmt, ExpressionStatement)
        
        exp = stmt.expression
        self.assertIsInstance(exp, IfExpression)
        self.assertEqual(str(exp.condition), "(x < y)")
        self.assertEqual(str(exp.consequence), "x")
        self.assertIsNotNone(exp.alternative)
        self.assertEqual(str(exp.alternative), "y")


if __name__ == '__main__':
    unittest.main()
