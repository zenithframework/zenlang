import click

@click.group()
def cli():
    """Zenith Framework CLI"""
    pass

if __name__ == "__main__":
    cli()
