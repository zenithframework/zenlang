from .token import Token, TokenType, lookup_identifier

class Lexer:
    def __init__(self, source: str):
        self.source = source
        self.position = 0  # current position in input (points to current char)
        self.read_position = 0  # current reading position in input (after current char)
        self.ch = ''  # current char under examination
        self._read_char()

    def _read_char(self):
        if self.read_position >= len(self.source):
            self.ch = ''  # EOF
        else:
            self.ch = self.source[self.read_position]
        self.position = self.read_position
        self.read_position += 1

    def _peek_char(self) -> str:
        if self.read_position >= len(self.source):
            return ''
        return self.source[self.read_position]

    def next_token(self) -> Token:
        self._skip_whitespace()

        token = None
        if self.ch == '=':
            if self._peek_char() == '=':
                ch = self.ch
                self._read_char()
                literal = ch + self.ch
                token = Token(TokenType.EQ, literal)
            else:
                token = Token(TokenType.ASSIGN, self.ch)
        elif self.ch == '+':
            token = Token(TokenType.PLUS, self.ch)
        elif self.ch == '-':
            token = Token(TokenType.MINUS, self.ch)
        elif self.ch == '!':
            if self._peek_char() == '=':
                ch = self.ch
                self._read_char()
                literal = ch + self.ch
                token = Token(TokenType.NOT_EQ, literal)
            else:
                token = Token(TokenType.BANG, self.ch)
        elif self.ch == '/':
            # Handle comments
            if self._peek_char() == '/':
                self._skip_single_line_comment()
                return self.next_token()
            elif self._peek_char() == '*':
                self._skip_multi_line_comment()
                return self.next_token()
            else:
                token = Token(TokenType.SLASH, self.ch)
        elif self.ch == '*':
            token = Token(TokenType.ASTERISK, self.ch)
        elif self.ch == '<':
            if self._peek_char() == '=':
                self._read_char()
                token = Token(TokenType.LTE, "<= ")
            else:
                token = Token(TokenType.LT, self.ch)
        elif self.ch == '>':
            if self._peek_char() == '=':
                self._read_char()
                token = Token(TokenType.GTE, ">=")
            else:
                token = Token(TokenType.GT, self.ch)
        elif self.ch == ';':
            token = Token(TokenType.SEMICOLON, self.ch)
        elif self.ch == ':':
            token = Token(TokenType.COLON, self.ch)
        elif self.ch == ',':
            token = Token(TokenType.COMMA, self.ch)
        elif self.ch == '(': 
            token = Token(TokenType.LPAREN, self.ch)
        elif self.ch == ')':
            token = Token(TokenType.RPAREN, self.ch)
        elif self.ch == '{':
            token = Token(TokenType.LBRACE, self.ch)
        elif self.ch == '}':
            token = Token(TokenType.RBRACE, self.ch)
        elif self.ch == '[':
            token = Token(TokenType.LBRACKET, self.ch)
        elif self.ch == ']':
            token = Token(TokenType.RBRACKET, self.ch)
        elif self.ch == '"':
            literal = self._read_string()
            token = Token(TokenType.STRING, literal)
        elif self.ch == '':
            token = Token(TokenType.EOF, "")
        else:
            if self.ch.isalpha() or self.ch == '_':
                literal = self._read_identifier()
                token_type = lookup_identifier(literal)
                return Token(token_type, literal)
            elif self.ch.isdigit():
                literal = self._read_number()
                if '.' in literal:
                    return Token(TokenType.FLOAT, literal)
                return Token(TokenType.INTEGER, literal)
            else:
                token = Token(TokenType.ILLEGAL, self.ch)
        
        self._read_char()
        return token

    def _read_identifier(self) -> str:
        position = self.position
        while self.ch.isalpha() or self.ch.isdigit() or self.ch == '_':
            self._read_char()
        return self.source[position:self.position]

    def _read_number(self) -> str:
        position = self.position
        while self.ch.isdigit() or self.ch == '.':
            self._read_char()
        return self.source[position:self.position]

    def _read_string(self) -> str:
        position = self.position + 1
        while True:
            self._read_char()
            if self.ch == '"' or self.ch == '':
                break
        return self.source[position:self.position]

    def _skip_whitespace(self):
        while self.ch in [' ', '\t', '\n', '\r']:
            self._read_char()
    
    def _skip_single_line_comment(self):
        while self.ch != '\n' and self.ch != '':
            self._read_char()

    def _skip_multi_line_comment(self):
        self._read_char() # Consume '*'
        while True:
            self._read_char()
            if self.ch == '*' and self._peek_char() == '/':
                self._read_char() # Consume '*'
                self._read_char() # Consume '/'
                break
            if self.ch == '': # EOF
                break
