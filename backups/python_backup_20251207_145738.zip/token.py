from typing import NamedTuple

class TokenType:
    # Special
    ILLEGAL = "ILLEGAL"
    EOF = "EOF"

    # Identifiers + literals
    IDENTIFIER = "IDENTIFIER"
    INTEGER = "INTEGER"
    FLOAT = "FLOAT"
    STRING = "STRING"

    # Operators
    ASSIGN = "="
    PLUS = "+"
    MINUS = "-"
    BANG = "!"
    ASTERISK = "*"
    SLASH = "/"
    LT = "<"
    GT = ">"
    EQ = "=="
    NOT_EQ = "!="
    LTE = "<="
    GTE = ">="

    # Delimiters
    COMMA = ","
    SEMICOLON = ";"
    COLON = ":"
    LPAREN = "("
    RPAREN = ")"
    LBRACE = "{"
    RBRACE = "}"
    LBRACKET = "["
    RBRACKET = "]"

    # Keywords
    FUNCTION = "FUNCTION"
    LET = "LET"
    CONST = "CONST"
    TRUE = "TRUE"
    FALSE = "FALSE"
    IF = "IF"
    ELSE = "ELSE"
    RETURN = "RETURN"
    CLASS = "CLASS"
    NEW = "NEW"
    PAGE = "PAGE"
    COMPONENT = "COMPONENT"


class Token(NamedTuple):
    token_type: str
    literal: str

# Keyword mapping
keywords = {
    "fn": TokenType.FUNCTION,
    "let": TokenType.LET,
    "const": TokenType.CONST,
    "true": TokenType.TRUE,
    "false": TokenType.FALSE,
    "if": TokenType.IF,
    "else": TokenType.ELSE,
    "return": TokenType.RETURN,
    "class": TokenType.CLASS,
    "new": TokenType.NEW,
    "page": TokenType.PAGE,
    "component": TokenType.COMPONENT,
}

def lookup_identifier(identifier: str) -> str:
    """Checks the keywords table for an identifier's token type."""
    return keywords.get(identifier, TokenType.IDENTIFIER)
