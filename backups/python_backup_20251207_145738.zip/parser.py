from .token import TokenType, Token
from .lexer import Lexer
from .ast import (
    Program, Statement, LetStatement, Identifier, ReturnStatement, ExpressionStatement, Expression,
    IntegerLiteral, PrefixExpression, InfixExpression, BooleanLiteral, BlockStatement, IfExpression
)
from typing import List, Optional, Dict, Callable

# Define type aliases for parsing functions
PrefixParseFn = Callable[[], Optional[Expression]]
InfixParseFn = Callable[[Expression], Optional[Expression]]

# Operator precedence
LOWEST = 1
EQUALS = 2       # ==
LESSGREATER = 3  # > or <
SUM = 4          # +
PRODUCT = 5      # *
PREFIX = 6       # -X or !X
CALL = 7         # myFunction(X)

precedences = {
    TokenType.EQ: EQUALS,
    TokenType.NOT_EQ: EQUALS,
    TokenType.LT: LESSGREATER,
    TokenType.GT: LESSGREATER,
    TokenType.PLUS: SUM,
    TokenType.MINUS: SUM,
    TokenType.SLASH: PRODUCT,
    TokenType.ASTERISK: PRODUCT,
    TokenType.LPAREN: CALL, # For function calls and grouped expressions
}

class Parser:
    def __init__(self, lexer: Lexer):
        self.lexer = lexer
        self.errors: List[str] = []

        self.current_token: Optional[Token] = None
        self.peek_token: Optional[Token] = None
        
        self.prefix_parse_fns: Dict[str, PrefixParseFn] = {}
        self.infix_parse_fns: Dict[str, InfixParseFn] = {}
        self._register_prefix(TokenType.IDENTIFIER, self._parse_identifier)
        self._register_prefix(TokenType.INTEGER, self._parse_integer_literal)
        self._register_prefix(TokenType.BANG, self._parse_prefix_expression)
        self._register_prefix(TokenType.MINUS, self._parse_prefix_expression)
        self._register_prefix(TokenType.TRUE, self._parse_boolean)
        self._register_prefix(TokenType.FALSE, self._parse_boolean)
        self._register_prefix(TokenType.LPAREN, self._parse_grouped_expression)
        self._register_prefix(TokenType.IF, self._parse_if_expression)

        self._register_infix(TokenType.PLUS, self._parse_infix_expression)
        self._register_infix(TokenType.MINUS, self._parse_infix_expression)
        self._register_infix(TokenType.SLASH, self._parse_infix_expression)
        self._register_infix(TokenType.ASTERISK, self._parse_infix_expression)
        self._register_infix(TokenType.EQ, self._parse_infix_expression)
        self._register_infix(TokenType.NOT_EQ, self._parse_infix_expression)
        self._register_infix(TokenType.LT, self._parse_infix_expression)
        self._register_infix(TokenType.GT, self._parse_infix_expression)

        self._next_token()
        self._next_token()

    def _next_token(self):
        self.current_token = self.peek_token
        self.peek_token = self.lexer.next_token()

    def parse_program(self) -> Program:
        program = Program()
        while self.current_token.token_type != TokenType.EOF:
            stmt = self._parse_statement()
            if stmt:
                program.statements.append(stmt)
            self._next_token()
        return program

    def _parse_statement(self) -> Optional[Statement]:
        if self.current_token.token_type == TokenType.LET:
            return self._parse_let_statement()
        elif self.current_token.token_type == TokenType.RETURN:
            return self._parse_return_statement()
        else:
            return self._parse_expression_statement()

    def _parse_let_statement(self) -> Optional[LetStatement]:
        stmt_token = self.current_token

        if not self._expect_peek(TokenType.IDENTIFIER):
            return None
        
        name = Identifier(token=self.current_token, value=self.current_token.literal)

        if not self._expect_peek(TokenType.ASSIGN):
            return None
        
        self._next_token()
        value_expression = self._parse_expression(LOWEST)
        
        if self.peek_token.token_type == TokenType.SEMICOLON:
            self._next_token()

        return LetStatement(token=stmt_token, name=name, value=value_expression)

    def _parse_return_statement(self) -> Optional[ReturnStatement]:
        stmt_token = self.current_token
        self._next_token()

        return_value = self._parse_expression(LOWEST)

        if self.peek_token.token_type == TokenType.SEMICOLON:
            self._next_token()
        
        return ReturnStatement(token=stmt_token, return_value=return_value)

    def _parse_expression_statement(self) -> ExpressionStatement:
        stmt = ExpressionStatement(token=self.current_token, expression=self._parse_expression(LOWEST))
        
        if self.peek_token.token_type == TokenType.SEMICOLON:
            self._next_token()
            
        return stmt

    def _parse_expression(self, precedence: int) -> Optional[Expression]:
        prefix = self.prefix_parse_fns.get(self.current_token.token_type)
        if not prefix:
            self.errors.append(f"no prefix parse function for {self.current_token.token_type} found")
            return None
        
        left_exp = prefix()

        while not self._peek_token_is(TokenType.SEMICOLON) and precedence < self._peek_precedence():
            infix = self.infix_parse_fns.get(self.peek_token.token_type)
            if not infix:
                return left_exp
            
            self._next_token()
            left_exp = infix(left_exp)

        return left_exp

    def _parse_identifier(self) -> Identifier:
        return Identifier(token=self.current_token, value=self.current_token.literal)

    def _parse_integer_literal(self) -> Optional[IntegerLiteral]:
        try:
            value = int(self.current_token.literal)
            return IntegerLiteral(token=self.current_token, value=value)
        except ValueError:
            self.errors.append(f"could not parse {self.current_token.literal} as integer")
            return None

    def _parse_boolean(self) -> BooleanLiteral:
        return BooleanLiteral(
            token=self.current_token,
            value=self.current_token.token_type == TokenType.TRUE
        )

    def _parse_grouped_expression(self) -> Optional[Expression]:
        self._next_token() # Consume '('
        exp = self._parse_expression(LOWEST)
        if not self._expect_peek(TokenType.RPAREN):
            return None
        return exp
    
    def _parse_if_expression(self) -> Optional[IfExpression]:
        token = self.current_token # The 'if' token
        if not self._expect_peek(TokenType.LPAREN):
            return None
        self._next_token() # Consume '('
        condition = self._parse_expression(LOWEST)
        if not self._expect_peek(TokenType.RPAREN):
            return None
        if not self._expect_peek(TokenType.LBRACE):
            return None
        consequence = self._parse_block_statement()
        alternative = None
        if self._peek_token_is(TokenType.ELSE):
            self._next_token() # Consume 'else'
            if not self._expect_peek(TokenType.LBRACE):
                return None
            alternative = self._parse_block_statement()
        return IfExpression(token=token, condition=condition, consequence=consequence, alternative=alternative)

    def _parse_block_statement(self) -> BlockStatement:
        block = BlockStatement(token=self.current_token) # The '{' token
        self._next_token() # Consume '{'

        while not self._current_token_is(TokenType.RBRACE) and not self._current_token_is(TokenType.EOF):
            stmt = self._parse_statement()
            if stmt:
                block.statements.append(stmt)
            # No self._next_token() here, it's handled by _parse_statement or loop condition check
        
        # After loop, current_token should be RBRACE or EOF.
        # Need to consume RBRACE if it's there
        if self._current_token_is(TokenType.RBRACE):
            self._next_token() # Consume '}'

        return block

    def _parse_prefix_expression(self) -> PrefixExpression:
        expression = PrefixExpression(
            token=self.current_token,
            operator=self.current_token.literal,
            right=None
        )
        self._next_token()
        expression.right = self._parse_expression(PREFIX)
        return expression

    def _parse_infix_expression(self, left: Expression) -> InfixExpression:
        expression = InfixExpression(
            token=self.current_token,
            operator=self.current_token.literal,
            left=left,
            right=None
        )
        precedence = self._current_precedence()
        self._next_token()
        expression.right = self._parse_expression(precedence)
        return expression

    def _expect_peek(self, token_type: str) -> bool:
        if self.peek_token.token_type == token_type:
            self._next_token()
            return True
        self._peek_error(token_type)
        return False
    
    def _peek_error(self, token_type: str):
        msg = f"expected next token to be {token_type}, got {self.peek_token.token_type} instead"
        self.errors.append(msg)
    
    def _peek_token_is(self, token_type: str) -> bool:
        return self.peek_token.token_type == token_type

    def _current_token_is(self, token_type: str) -> bool:
        return self.current_token.token_type == token_type

    def _peek_precedence(self) -> int:
        return precedences.get(self.peek_token.token_type, LOWEST)

    def _current_precedence(self) -> int:
        return precedences.get(self.current_token.token_type, LOWEST)

    def _register_prefix(self, token_type: str, fn: PrefixParseFn):
        self.prefix_parse_fns[token_type] = fn

    def _register_infix(self, token_type: str, fn: InfixParseFn):
        self.infix_parse_fns[token_type] = fn
